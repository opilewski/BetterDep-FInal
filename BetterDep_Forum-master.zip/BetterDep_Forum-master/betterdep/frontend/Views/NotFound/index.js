import React, { Component } from 'react';

class NotFound extends Component {
  render() {
    return (
      <h3>Coudn't found the url buddy. Please check it out.</h3>
    );
  }
}

export default NotFound;
