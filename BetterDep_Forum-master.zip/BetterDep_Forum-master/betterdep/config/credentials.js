module.exports = {
  GITHUB_CLIENT_ID: 'e9a1fadb155a3f96c048',
  GITHUB_CLIENT_SECRET: '6e126fb890cd33ab048a879bb597480b389ffb17',
  GITHUB_CALLBACK_URL: 'http://localhost:3030/api/user/authViaGitHub/callback',
  DBURL: 'mongodb://localhost:27017/test',
};
